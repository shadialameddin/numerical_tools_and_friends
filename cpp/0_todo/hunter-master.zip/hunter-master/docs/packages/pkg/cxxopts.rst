.. spelling::

    cxxopts

.. index:: commandline tools ; cxxopts

.. _pkg.cxxopts:

cxxopts
=======

-  `Official <https://github.com/jarro2783/cxxopts>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/cxxopts/CMakeLists.txt>`__

.. literalinclude:: /../examples/cxxopts/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
