.. spelling::

    sleef

.. index::
  single: cpu ; sleef

.. _pkg.sleef:

sleef
=====

-  `Official <https://github.com/shibatch/sleef>`__
-  `Hunterized <https://github.com/hunter-packages/sleef>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/sleef/CMakeLists.txt>`__
-  Added by `xsacha <https://github.com/xsacha>`__ (`pr-1780 <https://github.com/ruslo/hunter/pull/1780>`__)

.. literalinclude:: /../examples/sleef/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
