.. spelling::

    NLopt

.. index::
  single: unsorted ; NLopt

.. _pkg.NLopt:

NLopt
=====

-  `Official <https://github.com/stevengj/nlopt>`__
-  `Hunterized <https://github.com/hunter-packages/NLopt>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/NLopt/CMakeLists.txt>`__
-  Added by `t0p4 <https://github.com/t0p4>`__ (`pr-1617 <https://github.com/ruslo/hunter/pull/1617>`__)

.. literalinclude:: /../examples/NLopt/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
