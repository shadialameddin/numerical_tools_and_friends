.. spelling::

    sources
    for
    android
    sdk
    packer

.. index:: android_sdk_component ; sources_for_android_sdk_packer

.. _pkg.sources_for_android_sdk_packer:

sources_for_android_sdk_packer
==============================

-  `Official <https://github.com/hunter-packages/sources_for_android_sdk_packer>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/sources_for_android_sdk_packer/CMakeLists.txt>`__

.. literalinclude:: /../examples/sources_for_android_sdk_packer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
