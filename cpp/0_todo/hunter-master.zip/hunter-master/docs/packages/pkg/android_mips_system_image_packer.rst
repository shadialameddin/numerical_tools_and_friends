.. spelling::

    android
    mips
    system
    image
    packer

.. index:: android_sdk_component ; android_mips_system_image_packer

.. _pkg.android_mips_system_image_packer:

android_mips_system_image_packer
================================

-  `Official <https://github.com/hunter-packages/android_mips_system_image_packer>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/android_mips_system_image_packer/CMakeLists.txt>`__

.. literalinclude:: /../examples/android_mips_system_image_packer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
