.. spelling::

    range-v3

.. index:: unsorted ; range-v3

.. _pkg.range-v3:

range-v3
========

-  `Official <https://github.com/ericniebler/range-v3>`__
-  `Hunterized <https://github.com/hunter-packages/range-v3>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/range-v3/CMakeLists.txt>`__
-  Added by `dvirtz <https://github.com/dvirtz>`__ (`pr-1282 <https://github.com/ruslo/hunter/pull/1282>`__)

.. literalinclude:: /../examples/range-v3/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
