.. spelling::

    PROJ4

.. index:: GIS ; PROJ4

.. _pkg.PROJ4:

PROJ4
=====

-  `Official <https://github.com/OSGeo/proj.4>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/PROJ4/CMakeLists.txt>`__

.. literalinclude:: /../examples/PROJ4/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
