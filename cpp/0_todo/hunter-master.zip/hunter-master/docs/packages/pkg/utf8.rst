.. spelling::

    utf

.. index::
  single: text ; utf8

.. _pkg.utf8:

utf8
====

-  `Official <http://utfcpp.sourceforge.net/>`__
-  `Hunterized <https://github.com/hunter-packages/utf8>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/utf8/CMakeLists.txt>`__
-  Added by `Rahul Sheth <https://github.com/rbsheth>`__ (`pr-1711 <https://github.com/ruslo/hunter/pull/1711>`__)

.. literalinclude:: /../examples/utf8/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
