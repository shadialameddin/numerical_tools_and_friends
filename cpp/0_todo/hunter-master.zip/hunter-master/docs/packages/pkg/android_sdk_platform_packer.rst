.. spelling::

    android
    sdk
    platform
    packer

.. index:: android_sdk_component ; android_sdk_platform_packer

.. _pkg.android_sdk_platform_packer:

android_sdk_platform_packer
===========================

-  `Official <https://github.com/hunter-packages/android_sdk_platform_packer>`__
-  `Example <https://github.com/ruslo/hunter/blob/master/examples/android_sdk_platform_packer/CMakeLists.txt>`__

.. literalinclude:: /../examples/android_sdk_platform_packer/CMakeLists.txt
  :language: cmake
  :start-after: # DOCUMENTATION_START {
  :end-before: # DOCUMENTATION_END }
