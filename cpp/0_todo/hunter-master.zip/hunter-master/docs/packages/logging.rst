Logging
-------

 - :ref:`pkg.fmt` - Small, safe and fast formatting library
 - :ref:`pkg.glog` - C++ implementation of the Google logging module
 - :ref:`pkg.log4cplus` - simple to use C++ logging API providing thread-safe, flexible, and arbitrarily granular control over log management and configuration.
 - :ref:`pkg.spdlog` - Super fast C++ logging library.
