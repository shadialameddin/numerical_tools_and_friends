# Summary

* [Preface](01-Preface.md)
* [Use the Tools Available](02-Use_the_Tools_Available.md)
* [Style](03-Style.md)
* [Considering Safety](04-Considering_Safety.md)
* [Considering Maintainability](05-Considering_Maintainability.md)
* [Considering Portability](06-Considering_Portability.md)
* [Considering Threadability](07-Considering_Threadability.md)
* [Considering Performance](08-Considering_Performance.md)
* [Enable Scripting](09-Enable_Scripting.md)
* [Further Reading](10-Further_Reading.md)
* [Final Thoughts](11-Final_Thoughts.md)

