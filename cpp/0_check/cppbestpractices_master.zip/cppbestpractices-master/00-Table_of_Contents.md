
 1. [Preface](01-Preface.md)
 2. [Use the Tools Available](02-Use_the_Tools_Available.md)
 3. [Style](03-Style.md)
 4. [Considering Safety](04-Considering_Safety.md)
 5. [Considering Maintainability](05-Considering_Maintainability.md)
 6. [Considering Portability](06-Considering_Portability.md)
 7. [Considering Threadability](07-Considering_Threadability.md)
 8. [Considering Performance](08-Considering_Performance.md)
 9. [Enable Scripting](09-Enable_Scripting.md)
 10. [Further Reading](10-Further_Reading.md)
 11. [Final Thoughts](11-Final_Thoughts.md)


