#include "tbb/parallel_for.h"
#include <iostream>
#include <mex.h>
#include <omp.h>
#include <vector>

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Dense>
#include <eigen3/Eigen/Sparse>

// #include "storage_aliases.h"

#define int_space_ptr mxGetPr(prhs[0])
#define delta_ptr mxGetPr(prhs[1])
#define Hdo_raw prhs[2]
#define Hdo_ptr mxGetPr(prhs[2])
#define gradient_width int(*mxGetPr(prhs[10]))

#define output plhs[0]

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {

  // auto t1 = omp_get_wtime();
  using sparse_matrix = Eigen::SparseMatrix<double, Eigen::RowMajor>;
  using Matrix = Eigen::MatrixXd;
  using Vector = Eigen::VectorXd;
  using matrix6 = Eigen::Matrix<double, 6, 6>;
  using vector6 = Eigen::Matrix<double, 6, 1>;

  sparse_matrix A(ncomp * ngp, ncomp * ngp);
  sparse_matrix A_noint(ncomp * ngp, ncomp * ngp);
  Vector b(ngp * ncomp);
  Vector Q3_vec(ngp * ncomp);
  Vector space_mode(ngp * ncomp);

  double int_alpha_d_alpha = alpha.transpose() * int_time * d_alpha;
  Vector int_alpha_alpha = int_time * alpha.cwiseProduct(alpha);
  Vector int_alpha = int_time * alpha;
  Vector int_d_alpha = int_time * d_alpha;
  // auto t2 = omp_get_wtime();

  auto space_mode = K.llt().solve(F); // TODO: is this ok?

  output = mxCreateDoubleMatrix(ngp * ncomp, 1, mxREAL);
  Eigen::Map<Matrix>(mxGetPr(output), ngp * ncomp, 1) = space_mode;

  return;
}
