#include "mex.h"
#include "mxarray.h"

#include <Eigen/Cholesky>
#include <Eigen/Dense>
#include <Eigen/Eigenvalues>
#include <Eigen/LU>
#include <Eigen/Sparse>
#include <Eigen/StdVector>

#include <range/v3/all.hpp>
// #include <range/v3/core.hpp>

#include <iostream>
#include <vector>
// #include "matrix.h"
#include "tbb/parallel_for.h"
#include <omp.h>
// #include <tbb/tbb.h>
#include <typeinfo>
// #include <eigen3/Eigen/CXX11/Tensor>
// #include <unsupported/eigen3/Eigen/CXX11/Tensor>
// #include <Eigen/src/Core/util/DisableStupidWarnings.h>
// #include <Eigen/Tensor>
#include <unsupported/Eigen/CXX11/Tensor>

// #define ngp int(*mxGetPr(prhs[0]))
#define input prhs[0]
#define output plhs[0]

void check_input(int nlhs, int nrhs) {
  /* Check for proper number of arguments */
  // if (nrhs != 10) {
  //   mexErrMsgIdAndTxt("MATLAB:mexcpp:nargin",
  //                     "MEXCPP requires two input arguments.");
  // }
  // if(nlhs != 1) {mexErrMsgIdAndTxt("MATLAB:mexcpp:nargout","MEXCPP requires
  // no output argument.");}
  /* Check if the input is of proper type */
  // if(!mxIsDouble(sigma) || mxIsComplex(sigma))
  // {mexErrMsgIdAndTxt("MATLAB:mexcpp:typeargin","First argument has to be
  // double scalar.");} if(!mxIsDouble(D) || mxIsComplex(D))
  // {mexErrMsgIdAndTxt("MATLAB:mexcpp:typeargin","Second argument has to be
  // double scalar.");}
}

mxArray *cpp_to_MexArray(const std::vector<double> &v) {
  mxArray *mx = mxCreateDoubleMatrix(1, v.size(), mxREAL);
  std::copy(v.begin(), v.end(), mxGetPr(mx));

  return mx;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {

  check_input(nlhs, nrhs);

  if (!(mxIsStruct(prhs[0]) && mxGetNumberOfFields(prhs[0]) > 0)) {
    mexErrMsgIdAndTxt("MATLAB:mexcpp:typeargin",
                      "First argument has to be double scalar.");
    return;
  }
  auto eps_p_bar = mxGetField(prhs[0], 0, "eps_p_bar");
  auto sigma_bar = mxGetField(prhs[0], 0, "sigma_bar");
  auto Hdo = mxGetField(prhs[0], 0, "Hdo");
  auto inv_Hdo = mxGetField(prhs[0], 0, "iHdo");
  auto delta_in = mxGetField(prhs[0], 0, "delta");
  auto DG_proj = mxGetField(prhs[0], 0, "DG_proj");
  auto D_operator = mxGetField(prhs[0], 0, "D_operator");
  auto ntp_in = mxGetField(prhs[0], 0, "ntp");
  auto dt = mxGetField(prhs[0], 0, "dt");
  auto I_g = mxGetField(prhs[0], 0, "I_g");
  auto sgn = mxGetField(prhs[0], 0, "sign");

  auto sign = int(*mxGetPr(sgn));
  auto d_t = double(*mxGetPr(dt));

  auto Hdo_Dimensions = mxGetDimensions(Hdo);
  auto sigma_Dimensions = mxGetDimensions(sigma_bar);
  int const ncomp = Hdo_Dimensions[0];
  int const ngp = Hdo_Dimensions[2];
  int const ntp = Hdo_Dimensions[3];
  int const nmodes = sigma_Dimensions[1];

  using namespace mexplus;
  using namespace std;
  using Matrix = Eigen::MatrixXd;
  using Matrix3 = Eigen::Matrix3d;
  using Vector3 = Eigen::Vector3d;
  using Vector = Eigen::VectorXd;
  using matrix6 = Eigen::Matrix<double, 6, 6>;
  using tensor4 = Eigen::Tensor<double, 4>;
  using tensor3 = Eigen::Tensor<double, 3>;
  // typedef Eigen::Map<Matrix> tensor_map;
  // typedef Eigen::Map<Matrix> matrix_map;

  // vector<int> HHHH = MxArray::to<vector<int>>(Hdo); // TODO -> to vector

  // TODO -> row or column
  Eigen::Map<matrix6> Int_space(mxGetPr(I_g));

  Eigen::Map<Vector> Hdo_v(mxGetPr(Hdo), ntp * ngp * ncomp * ncomp);
  Eigen::Map<Vector> inv_Hdo_v(mxGetPr(inv_Hdo), ntp * ngp * ncomp * ncomp);
  Eigen::Map<Vector> delta_v(mxGetPr(delta_in), ntp * ngp * ncomp);
  Eigen::Map<Vector> sigma_v(mxGetPr(sigma_bar), ngp * ncomp * nmodes);
  Eigen::Map<Vector> eps_p_v(mxGetPr(eps_p_bar), ngp * ncomp * nmodes);

  std::vector<std::vector<matrix6>> H(ntp, std::vector<matrix6>(ngp));
  std::vector<std::vector<matrix6>> iH(ntp, std::vector<matrix6>(ngp));
  std::vector<std::vector<Vector>> delta(
      ntp, std::vector<Vector>(ngp, Vector(ncomp)));
  std::vector<Matrix> sigma(ngp, Matrix(ncomp, nmodes));
  std::vector<Matrix> eps_p(ngp, Matrix(ncomp, nmodes));
  // std::vector<std::vector<Vector>> delta(
  //     ntp, std::vector<Eigen::VectorXd<double, ncomp>>(ngp));

  auto const tensor_shift = ncomp * ncomp;
  auto const vector_shift = ncomp * nmodes;
  auto const delta_shift = ncomp;
  // tbb::parallel_for(std::size_t{0}, deformation_gradients.size(), [&](auto
  // const l)

  // tbb::parallel_for(std::size_t{0}, ntp, [&](auto const i)) {
  // #pragma omp paralle for collapse(2) reduction(2 : A)
#pragma omp parallel for collapse(2)
  for (size_t i = 0; i < ntp; i++) {
    for (size_t j = 0; j < ngp; j++) {
      // cout << Eigen::Map<matrix6>(Hdo_v.data()) << endl; //
      // TODO use this
      auto tensor_idx = (i * ngp + j) * tensor_shift;
      auto delta_idx = (i * ngp + j) * delta_shift;
      H[i][j] << Hdo_v.segment(tensor_idx, tensor_shift);
      iH[i][j] << inv_Hdo_v.segment(tensor_idx, tensor_shift);
      delta[i][j] << delta_v.segment(delta_idx, delta_shift);
    }
  }

#pragma omp parallel for
  for (size_t j = 0; j < ngp; j++) {
    auto vector_idx = j * vector_shift;
    sigma[j] << sigma_v.segment(vector_idx, vector_shift);
    eps_p[j] << eps_p_v.segment(vector_idx, vector_shift);
    // std::cout << omp_get_num_threads();
  }

  std::vector<Matrix> a11(ntp, Matrix::Zero(nmodes, nmodes));
  std::vector<Matrix> a10(ntp, Matrix::Zero(nmodes, nmodes));
  std::vector<Matrix> a01(ntp, Matrix::Zero(nmodes, nmodes));
  std::vector<Matrix> a00(ntp, Matrix::Zero(nmodes, nmodes));
  std::vector<Vector> d1(ntp, Vector::Zero(nmodes));
  std::vector<Vector> d0(ntp, Vector::Zero(nmodes));

#pragma omp parallel for collapse(2)
  for (size_t i = 0; i < ntp; i++) {
    for (size_t j = 0; j < ngp; j++) {
      a11[i] += eps_p[j].transpose() * iH[i][j] * Int_space * eps_p[j];
      a10[i] += -1.0 * sign * eps_p[j].transpose() * Int_space * sigma[j];
      a00[i] += sigma[j].transpose() * H[i][j] * Int_space *
                sigma[j]; // TODO I_g is the same for all elements? shouldn't be
      d1[i] += -1.0 * sign * eps_p[j].transpose() * iH[i][j] * Int_space *
               delta[i][j];
      d0[i] += sigma[j].transpose() * Int_space * delta[i][j];
    }
  }
  a01 = a10;

  std::vector<Matrix> t11(ntp, Matrix(nmodes, nmodes));
  std::vector<Matrix> t12(ntp, Matrix(nmodes, nmodes));
  std::vector<Matrix> t21(ntp, Matrix(nmodes, nmodes));
  std::vector<Matrix> t22(ntp, Matrix(nmodes, nmodes));
  std::vector<Vector> b1(ntp, Vector(nmodes));
  std::vector<Vector> b0(ntp, Vector(nmodes));

#pragma omp parallel for
  for (size_t i = 0; i < ntp; i++) {
    t11[i] = a11[i] / (d_t * d_t); // TODO use cwiseQuotient
    t12[i] = a01[i] / (d_t);
    t22[i] = t11[i] + t12[i] + t12[i] + a00[i];
    t12[i] = -t12[i] - t11[i];
    b0[i] = -d1[i] / (d_t);
    b1[i] = d1[i] / (d_t) + d0[i];
  }

  auto nel = ntp - 1;

  Matrix A = Matrix::Zero(nmodes * ntp, nmodes * ntp);
  Vector b = Vector::Zero(ntp * nmodes);

  Matrix a_el(2 * nmodes, 2 * nmodes);
  Vector b_el(2 * nmodes);

  std::vector<std::int32_t> dofs;
  for (size_t j = 0; j < nel * nmodes; j += nmodes) {
    dofs.push_back(j);
  }
  auto idx = Vector::LinSpaced(nel, 0, nel * nmodes);

  for (size_t i = 0; i < nel; i++) {
    // clang-format off
    // a_el.block(0,0,nmodes, nmodes) = t11[i+1];
    a_el << t11[i+1], t12[i+1],
         t12[i+1], t22[i+1];

    b_el << b0[i+1],
         b1[i+1]; // TODO use I_time
    // clang-format on

    A.block(dofs.at(i), dofs.at(i), 2 * nmodes, 2 * nmodes) +=
        a_el; // TODO this assembly is not final
    b.segment(dofs.at(i), 2 * nmodes) +=
        b_el; // TODO this assembly is not final
  }

  std::vector<std::int32_t> fixed_dofs;
  for (size_t j = 0; j < nmodes; j++) {
    fixed_dofs.push_back(j);
  }

  for (auto const fixed_dof : fixed_dofs) {
    auto const diagonal_entry = A.coeff(fixed_dof, fixed_dof);

    b(fixed_dof) = 0.0;

    std::vector<int> non_zero_visitor;

    // using sparse_matrix = Eigen::SparseMatrix<double, Eigen::RowMajor>; //
    // TODO // sparse

    A.col(fixed_dof) = 0.0 * A.col(fixed_dof);
    A.row(fixed_dof) = 0.0 * A.row(fixed_dof);
    // Reset the diagonal to the same value to preserve conditioning
    A.coeffRef(fixed_dof, fixed_dof) = diagonal_entry;
  }

  // std::cout << A << '\n';
  // std::cout << b << '\n';

  Vector x = A.lu().solve(b);
  // std::cout << x << '\n';

  // auto nDimNum = mxGetNumberOfDimensions(eps_p_bar);
  // auto pDims = mxGetDimensions(eps_p_bar);
  // // std::vector<int> const ddim = {{ngp, nmodes, ncomp}};
  // output = mxCreateNumericArray(nDimNum, pDims, mxDOUBLE_CLASS, mxREAL);
  // output = MxArray::from(20);
  //

  output = mxCreateDoubleMatrix(nmodes, ntp, mxREAL);
  auto out_pt = mxGetPr(output);
  Eigen::Map<Eigen::MatrixXd> mapp(out_pt, nmodes, ntp);
  mapp = x; // copy
  // std::copy(x.begin(), x.end(), mxGetPr(output));
  return;
  // Eigen::JacobiSVD<Eigen::MatrixXd> svd(M);
  // double cond = svd.singularValues()(0) /
  // svd.singularValues()(svd.singularValues().size()
  // - 1); std::cout << cond << "\n\n";
  // vector a = -M.inverse() * f;
  // y -= M.fullPivLu().solve(f);

  // output = MxArray::from(vector<double>(20, 0));

  // auto nDimNum = mxGetNumberOfDimensions(eps_p_bar);
  // auto pDims = mxGetDimensions(eps_p_bar);
  // // std::vector<int> const ddim = {{ngp, nmodes, ncomp}};
  // output = mxCreateNumericArray(nDimNum, pDims, mxDOUBLE_CLASS, mxREAL);
  // output = eps_p_bar;

  // TODO sparse matrices
  // TODO check for double mxIsDouble

  // Eigen::TensorMap<tensor3> out(mxGetPr(output), ngp, nmodes, ncomp);
  // out = eps_p_t;

  // Eigen::TensorMap<Eigen::Tensor<double, 3, Eigen::RowMajor>>(
  //     mxGetPr(output), ngp, ntp, ncomp) = eps_p_t; // TODO this is a copy

  // Eigen::Map<Matrix<double, 2, 5>>(p, 2, 5) = m;

  output = MxArray::from(20);

  std::cout << "/* done mex */" << '\n';
  return;
}

//
// // clang-format off
// // TODO check for double mxIsDouble
// double *eps_p_bar_ptr = mxGetPr(eps_p_bar);
// Matrix eps_p_bar_eigen = Eigen::Map<Eigen::MatrixXd>(eps_p_bar_ptr, ncomp,
// ngp); // Map the array std::vector<Matrix> eps_p_bar_vec(ngp); for (size_t
// i
//
// auto out_pt = mxGetPr(output);
// Eigen::Map<Eigen::MatrixXd> mapp(out_pt, ncomp, ngp);
// mapp = eps_p_bar_eigen; // copy
//
// // TODO what about 3D arrays & ...
// // TODO sparse matrices
// /* Acquire pointers to the input data */
// output = mxCreateNumericArray(4, Hdo_Dimensions, mxDOUBLE_CLASS,
//                               mxREAL);
//
// std::cout << typeid(4).name() << '\n';
// std::cout << typeid(Hdo_Dimensions).name() << '\n';
//
// Matrix3 sigma_i_j = Matrix3::Zero(); // Aa.setZero(3,3);
// Matrix3 eps_e_i_j = Matrix3::Zero(); // Aa.setZero(3,3);
// Vector3 x;
// Matrix3 v;
//
// // Matrix sigmaX = Matrix::Zero(10, 10);
// // Matrix sigmaX =
// //     Eigen::Map<Matrix<double, 10, 10>, Unaligned, Stride<1, 4>>(sigma);
