#include "mex.h"

// .selfadjointView<Upper>()
// mex -I"/home/alameddin/packages/include" effective_mex.cpp
// >> mex -I"/home/alameddin/packages/include" Class/Solvers/SN_Latin/Operators/effective_mex.cpp

//#include <eigen3/Eigen/Dense>
//#include <eigen3/Eigen/Sparse>
//#include <eigen3/Eigen/Eigenvalues>

#include <Eigen/Dense>
#include <Eigen/Sparse>
#include <Eigen/Eigenvalues>

#include <iostream>
#include <vector>
#include <complex>

// #include "matrix.h"
// #include <typeinfo>

using namespace Eigen;

//#define ntp         int(*mxGetPr(prhs[1]))

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
//*********************************************
	/* get the values from the struct 1x1 */
//	MKL_INT NoTimeStep = (MKL_INT) mxGetScalar(mxGetField(prhs[0], 0, "NoTimeStep"));
//	MKL_INT N_DoF = (MKL_INT) mxGetScalar(mxGetField(prhs[0], 0, "N_DoF")); // number of dof per element
//	double dt = (double) mxGetScalar(mxGetField(prhs[0], 0, "dt")); // number of dof per element
//*********************************************
//*********************************************
	/* get the values from the struct Matrix mx1*/
	double *v0 = (double *) mxGetPr(mxGetField(prhs[1], 0, "v0"));
//	MKL_INT *TIMEPLOT_pr = (MKL_INT*) mxGetPr(mxGetField(prhs[1], 0, "TIMEPLOT"));
//	MKL_INT LengthTIMEPLOT = (MKL_INT) mxGetScalar(mxGetField(prhs[0], 0, "LengthTIMEPLOT")); // number of dof per element
//	double *rhs = (double *) mxGetPr(mxGetField(prhs[1], 0, "rhs"));
	//*********************************************

	//--stiffness matrix--
	int m_K = mxGetM(mxGetField(prhs[2], 0, "K"));
	int n_K = mxGetN(mxGetField(prhs[2], 0, "K"));
	int nnz_K = mxGetNzmax(mxGetField(prhs[2], 0, "K"));
	double *nnzval_K_csc = mxGetPr(mxGetField(prhs[2], 0, "K"));
	size_t *rowind_LHS_csc = mxGetIr(mxGetField(prhs[2], 0, "K"));
	size_t *colptr_LHS_csc = mxGetJc(mxGetField(prhs[2], 0, "K"));

	int outerIndexPtr[n_K + 1];
	int innerIndices[nnz_K];
	double values[nnz_K];
	VectorXd vv(nnz_K);

	int couter = 0;
	for (int i = 0; i < nnz_K; i++)
	{
		values[i] = nnzval_K_csc[i];
		vv(i) = nnzval_K_csc[i];
	}
	std::cout << "sparse matrix is: " << nnz_K << std::endl;
	std::cout << "sparse matrix is: " << vv << std::endl;

	Map < SparseMatrix<double> > sm1(m_K, n_K, nnz_K, outerIndexPtr, innerIndices, values);

//	sm1.setZero();
//	std::cout << "sparse matrix is: " << values << std::endl;
//	std::cout << "sparse matrix is: "<< sm1 << std::endl;
//	std::cout << "innerIndextr is: "<< sm1.nonZeros() << std::endl;

	/*************** convert to matlab ****************/
	//	* Out put *//* Out put *//* Out put *//* Out put *//* Out put *//* Out put */
	plhs[0] = mxCreateDoubleMatrix(20, 20, mxREAL);
	double *pr_out0 = mxGetPr(plhs[0]); // pointer pr_out will manage data in COLUMN Major.
	plhs[1] = mxCreateDoubleMatrix(3, 3, mxREAL);
	double *pr_out1 = mxGetPr(plhs[1]); // pointer pr_out will manage data in COLUMN Major.
	plhs[2] = mxCreateDoubleMatrix(3, 3, mxREAL);
	double *pr_out2 = mxGetPr(plhs[2]); // pointer pr_out will manage data in COLUMN Major.

	for (int i = 0; i < nnz_K; i++)
	{
		pr_out0[i] = nnzval_K_csc[i];
	}
	return;
}
