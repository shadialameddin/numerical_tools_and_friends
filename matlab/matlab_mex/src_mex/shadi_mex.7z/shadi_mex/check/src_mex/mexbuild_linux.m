clear all; clc; close all;

% mex -I"D:\Dropbox\SubCodes\Eigen-3.3.4" eigen_matlab_mex.cpp

mex -I"/home/chuongnguyen/Documents/Dropbox/SubCodes/Eigen-3.3.4" eigen_matlab2_mex.cpp