clear all;
clc;
close all;

% load sparse_matrix_real
% load sparse_matrix_image
load full_matrix_real
% load full_matrix_image
%% Mex file
%% Input data to mexfile
prhs1x1={};
prhsmx1={};
prhsmxn={};
%% % Scalar type %%%%%
% prhs1x1.delH=delH;
%% % Vector mx1 type %%%%%
prhsmx1.v0=rand(size(K,2),1);
%% % Matrix type mxn %%%%%
prhsmxn.M=M;
K=[0 3 0 0 0;
    22 0 0 0 17;
    7 5 0 1 0;
    0 0 0 0	0;
    0 0 14 0 8];
prhsmxn.K=sparse(K);
% prhsmxn.K=(K);
tic
[dCeH,dVol,dR]=eigen_matlab2_mex(prhs1x1,prhsmx1,prhsmxn);
toc
return
