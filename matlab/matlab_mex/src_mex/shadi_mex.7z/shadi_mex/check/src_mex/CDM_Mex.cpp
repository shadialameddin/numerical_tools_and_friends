#include "mex.h"
#include "mkl.h"
#include "mkl_pardiso.h"
#include <stdio.h>
#include <string.h>
#include "omp.h"
#include "mkl_service.h"
#include "math.h"
#include <stdlib.h>
//*******************Changing***************************
//Without damping matrix
//full geometry, no symmetric boundarycondition
//********************************************************

//#include "mkl_lapacke.h"
//#include "lapack.h"

//typedef size_t INT;
//#define MKL_INT INT
//#ifndef lapack_int
//#define lapack_int MKL_INT
//#endif
//written by Chau Nguyen Khanh
#define MIN(a, b) ((a) < (b) ? (a) : (b))
//#ifdef __cplusplus
//extern "C" bool utIsInterruptPending();
//#else
//extern bool utIsInterruptPending();
//#endif

#if defined(NAN_EQUALS_ZERO)
#define IsNonZero(d) ((d)!=0.0 || mxIsNaN(d))
#else
#define IsNonZero(d) ((d)!=0.0)
#endif

#define PI acos(-1.0)

/* Auxiliary routine: printing a vector of integers */

//Dynamic force
double force(double x) // [bathe2016a, eq.20, p.59)
{
//	double i;
//	if ((1 - x) >= 0)
//	{
//		i = 1.0;
//	}
//	else
//	{
//		i = 0.0;
//	}

//	double f, Af, fp, ts; /*[bathe2016a, eq.20, p.59)*/
//	Af = 2 * pow(10.0, 6); // N/m
//	fp = 10; // Hz
//	ts = 0.1; // second
//	f = Af * (1 - 2 * pow(PI * fp * (x - ts), 2)) * exp(-1 * pow(PI * fp * (x - ts), 2));
//	return 1.0 * f; // No symetric BCs applied

	double fhat, t0, fpi, f; /*[Noh, Bathe 2013*/
	fhat = 12.5;
	t0 = 0.1;
	fpi = pow(PI * fhat * (x - t0), 2);
	f = -1 * pow(10.0, 6) * (1 - 2 * fpi) * exp(-1 * fpi);
	return 1.0 * f; // No symetric BCs applied
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
//*********************************************
	/* get the values from the struct 1x1 */
	MKL_INT NoTimeStep = (MKL_INT) mxGetScalar(mxGetField(prhs[0], 0, "NoTimeStep"));
	MKL_INT N_DoF = (MKL_INT) mxGetScalar(mxGetField(prhs[0], 0, "N_DoF")); // number of dof per element
	double dt = (double) mxGetScalar(mxGetField(prhs[0], 0, "dt")); // number of dof per element
//*********************************************
	/* get the values from the struct Matrix mx1*/
	double *TIME_vec_pr = (double *) mxGetPr(mxGetField(prhs[1], 0, "TIME_vec"));
	MKL_INT *TIMEPLOT_pr = (MKL_INT*) mxGetPr(mxGetField(prhs[1], 0, "TIMEPLOT"));
	MKL_INT LengthTIMEPLOT = (MKL_INT) mxGetScalar(mxGetField(prhs[0], 0, "LengthTIMEPLOT")); // number of dof per element
	double *rhs = (double *) mxGetPr(mxGetField(prhs[1], 0, "rhs"));
	double *u0 = (double *) mxGetPr(mxGetField(prhs[1], 0, "u0"));

	//*********************************************

	mkl_set_dynamic(0);
	//int h = mkl_get_dynamic();
	//mkl_domain_set_num_threads(1, MKL_DOMAIN_PARDISO);
	MKL_INT num_threads = mkl_get_max_threads();
	mkl_set_num_threads(num_threads);
//	size_t num_threads = omp_get_max_threads();
//	omp_set_num_threads(num_threads);

	MKL_INT job[6];
	job[0] = 1; //the matrix in the CSC format is converted to the CSR format
	job[1] = 1; //one-based indexing for the matrix in CSR format is used
	job[2] = 0; //zero-based indexing for the matrix in the CSC format is used
	job[5] = 1; //all output arrays acsr, ja, and ia are filled in for the output storage.
	int info;

	char trans = 'N';
	MKL_INT request; //computes only values of the array row_ptr_IsK_AuIn
	MKL_INT sort; //reordering output
	char matdescra[6];
	matdescra[0] = 'G';
	matdescra[2] = 'N';
	matdescra[3] = 'F';
	const double beta1 = 1.0;
	const double alpha1m = -1.0;

	//	Configs for pardiso solver
	MKL_INT maxfct = 1;
	MKL_INT mnum = 1;
	MKL_INT phase;
	MKL_INT *perm;
	MKL_INT num_rhs = 1;
	MKL_INT msglvl = 0;
	MKL_INT error = 1;
	double x;

	/* get the values from the struct Matrix m x n */
	//--stiffness matrix--
	MKL_INT m_K = mxGetM(mxGetField(prhs[2], 0, "K"));
	MKL_INT n_K = mxGetN(mxGetField(prhs[2], 0, "K"));
	double *nnzval_K_csc = mxGetPr(mxGetField(prhs[2], 0, "K"));
	size_t *rowind_K_csc = mxGetIr(mxGetField(prhs[2], 0, "K"));
	size_t *colptr_K_csc = mxGetJc(mxGetField(prhs[2], 0, "K"));
	MKL_INT nnz_K = mxGetNzmax(mxGetField(prhs[2], 0, "K"));

	//convert to MKL_INT data type
	MKL_INT *jc_K_csc = (MKL_INT *) mxMalloc((n_K + 1) * sizeof(MKL_INT));
	MKL_INT *ir_K_csc = (MKL_INT *) mxMalloc(nnz_K * sizeof(MKL_INT));
	for (MKL_INT i = 0; i < n_K + 1; i++)
	{
		jc_K_csc[i] = (MKL_INT) colptr_K_csc[i];
	}
	for (MKL_INT i = 0; i < nnz_K; i++)
	{
		ir_K_csc[i] = (MKL_INT) rowind_K_csc[i];
	}
	double *nnzval_K_csr = (double*) mxMalloc(nnz_K * sizeof(double));
	MKL_INT *colind_K_csr = (MKL_INT*) mxMalloc(nnz_K * sizeof(MKL_INT));
	MKL_INT *rowptr_K_csr = (MKL_INT*) mxMalloc((m_K + 1) * sizeof(MKL_INT));
	mkl_dcsrcsc(job, &m_K, nnzval_K_csr, colind_K_csr, rowptr_K_csr, nnzval_K_csc, ir_K_csc, jc_K_csc, &info);
	mxFree(jc_K_csc);
	mxFree(ir_K_csc);

	//--Mass matrix--
	MKL_INT m_M = mxGetM(mxGetField(prhs[2], 0, "M"));
	MKL_INT n_M = mxGetN(mxGetField(prhs[2], 0, "M"));
	double *nnzval_M_csc = mxGetPr(mxGetField(prhs[2], 0, "M"));
	size_t *rowind_M_csc = mxGetIr(mxGetField(prhs[2], 0, "M"));
	size_t *colptr_M_csc = mxGetJc(mxGetField(prhs[2], 0, "M"));
	MKL_INT nnz_M = mxGetNzmax(mxGetField(prhs[2], 0, "M"));

	//convert to MKL_INT data type
	MKL_INT *jc_M_csc = (MKL_INT *) mxMalloc((n_M + 1) * sizeof(MKL_INT));
	MKL_INT *ir_M_csc = (MKL_INT *) mxMalloc(nnz_M * sizeof(MKL_INT));
	for (MKL_INT i = 0; i < n_M + 1; i++)
	{
		jc_M_csc[i] = (MKL_INT) colptr_M_csc[i];
	}
	for (MKL_INT i = 0; i < nnz_M; i++)
	{
		ir_M_csc[i] = (MKL_INT) rowind_M_csc[i];
	}
	double *nnzval_M_csr = (double*) mxMalloc(nnz_M * sizeof(double));
	MKL_INT *colind_M_csr = (MKL_INT*) mxMalloc(nnz_M * sizeof(MKL_INT));
	MKL_INT *rowptr_M_csr = (MKL_INT*) mxMalloc((m_M + 1) * sizeof(MKL_INT));
	mkl_dcsrcsc(job, &m_M, nnzval_M_csr, colind_M_csr, rowptr_M_csr, nnzval_M_csc, ir_M_csc, jc_M_csc, &info);
	mxFree(jc_M_csc);
	mxFree(ir_M_csc);

	//--Damp matrix--
	MKL_INT m_C = mxGetM(mxGetField(prhs[2], 0, "C"));
	MKL_INT n_C = mxGetN(mxGetField(prhs[2], 0, "C"));
	double *nnzval_C_csc = mxGetPr(mxGetField(prhs[2], 0, "C"));
	size_t *rowind_C_csc = mxGetIr(mxGetField(prhs[2], 0, "C"));
	size_t *colptr_C_csc = mxGetJc(mxGetField(prhs[2], 0, "C"));
	MKL_INT nnz_C = mxGetNzmax(mxGetField(prhs[2], 0, "C"));

	//convert to MKL_INT data type
	MKL_INT *jc_C_csc = (MKL_INT *) mxMalloc((n_C + 1) * sizeof(MKL_INT));
	MKL_INT *ir_C_csc = (MKL_INT *) mxMalloc(nnz_C * sizeof(MKL_INT));
	for (MKL_INT i = 0; i < n_C + 1; i++)
	{
		jc_C_csc[i] = (MKL_INT) colptr_C_csc[i];
	}
	for (MKL_INT i = 0; i < nnz_C; i++)
	{
		ir_C_csc[i] = (MKL_INT) rowind_C_csc[i];
	}
	double *nnzval_C_csr = (double*) mxMalloc(nnz_C * sizeof(double));
	MKL_INT *colind_C_csr = (MKL_INT*) mxMalloc(nnz_C * sizeof(MKL_INT));
	MKL_INT *rowptr_C_csr = (MKL_INT*) mxMalloc((m_C + 1) * sizeof(MKL_INT));
	mkl_dcsrcsc(job, &m_C, nnzval_C_csr, colind_C_csr, rowptr_C_csr, nnzval_C_csc, ir_C_csc, jc_C_csc, &info);
	mxFree(jc_C_csc);
	mxFree(ir_C_csc);

	//---------------------------------------------compute LHS = M/dt^2 + C/2/dt;------------------------------------------------------
	//--LHS matrix--
	MKL_INT m_LHS = mxGetM(mxGetField(prhs[2], 0, "LHS"));
	MKL_INT n_LHS = mxGetN(mxGetField(prhs[2], 0, "LHS"));
	double *nnzval_LHS_csc = mxGetPr(mxGetField(prhs[2], 0, "LHS"));
	size_t *rowind_LHS_csc = mxGetIr(mxGetField(prhs[2], 0, "LHS"));
	size_t *colptr_LHS_csc = mxGetJc(mxGetField(prhs[2], 0, "LHS"));
	MKL_INT nnz_LHS = mxGetNzmax(mxGetField(prhs[2], 0, "LHS"));

	//convert to MKL_INT data type
	MKL_INT *jc_LHS_csc = (MKL_INT *) mxMalloc((n_LHS + 1) * sizeof(MKL_INT));
	MKL_INT *ir_LHS_csc = (MKL_INT *) mxMalloc(nnz_LHS * sizeof(MKL_INT));
	for (MKL_INT i = 0; i < n_LHS + 1; i++)
	{
		jc_LHS_csc[i] = (MKL_INT) colptr_LHS_csc[i];
	}
	for (MKL_INT i = 0; i < nnz_LHS; i++)
	{
		ir_LHS_csc[i] = (MKL_INT) rowind_LHS_csc[i];
	}
	double *nnzval_LHS_csr = (double*) mxMalloc(nnz_LHS * sizeof(double));
	MKL_INT *colind_LHS_csr = (MKL_INT*) mxMalloc(nnz_LHS * sizeof(MKL_INT));
	MKL_INT *rowptr_LHS_csr = (MKL_INT*) mxMalloc((m_LHS + 1) * sizeof(MKL_INT));
	mkl_dcsrcsc(job, &m_LHS, nnzval_LHS_csr, colind_LHS_csr, rowptr_LHS_csr, nnzval_LHS_csc, ir_LHS_csc, jc_LHS_csc,
			&info);
	mxFree(jc_LHS_csc);
	mxFree(ir_LHS_csc);

	// Initial Conditon TIME=0;
	MKL_INT TIMEi = 0;
	MKL_INT timenodeadd = 0;
	double TIME = TIME_vec_pr[TIMEi];
//	double *u0 = (double *) mxCalloc(N_DoF, sizeof(double));
	double *v0 = (double *) mxCalloc(N_DoF, sizeof(double));
	double *a0 = (double *) mxCalloc(N_DoF, sizeof(double));
	double *RHS = (double *) mxCalloc(N_DoF, sizeof(double));
	double *RHSTemp = (double *) mxCalloc(N_DoF, sizeof(double));

	cblas_daxpy(N_DoF, force(TIME), rhs, 1, RHS, 1);
	cblas_dcopy(N_DoF, RHS, 1, RHSTemp, 1); //	F(FreeIdcs)
	mkl_dcsrmv(&trans, &m_K, &n_K, &alpha1m, matdescra, nnzval_K_csr, colind_K_csr, rowptr_K_csr, rowptr_K_csr + 1, u0,
			&beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u0
	mkl_dcsrmv(&trans, &m_C, &n_C, &alpha1m, matdescra, nnzval_C_csr, colind_C_csr, rowptr_C_csr, rowptr_C_csr + 1, v0,
			&beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u0 -C_Damp*v0

// config for Pariso
	_MKL_DSS_HANDLE_t ptM[64];
	MKL_INT mtypeM = 1; //	real and structurally symmetric
	MKL_INT iparmM[64];
	PARDISOINIT(&ptM, &mtypeM, iparmM);
	iparmM[1] = 3; //parallel fill-in reducing ordering
	iparmM[4] = 0; //User permutation in the perm array is ignored.
	iparmM[5] = 0; //The array x contains the solution; right-hand side vector b is kept unchanged.

	iparmM[23] = 1; //use two-level scheduling factorization algorithm
	//iparmM[24] = 1; //uses the sequential forward and backward solve.
	iparmM[26] = 1; //enable matrix checker
	iparmM[34] = 0; //use one-based indexing
	iparmM[36] = 0; //Use CSR format (see Three Array Variation of CSR Format) for matrix storage.
	//Analysis, Numerical factorization
	phase = 12;
	PARDISO(ptM, &maxfct, &mnum, &mtypeM, &phase, &m_M, nnzval_M_csr, rowptr_M_csr, colind_M_csr, perm, &num_rhs,
			iparmM, &msglvl, &x, &x, &error);
	if (error != 0)
	{
		switch (error)
		{
		case -1:
			mexErrMsgTxt("MKL Pardiso: analysis and numerical factorization error: input inconsistent");
			break;
		case -2:
			mexErrMsgTxt("MKL Pardiso: analysis and numerical factorization error: not enough memory");
			break;
		default:
			mexErrMsgTxt("MKL Pardiso: analysis and numerical factorization error");
			break;
		}
	}
	//Solve, iterative refinement
	phase = 33;
	PARDISO(ptM, &maxfct, &mnum, &mtypeM, &phase, &m_M, nnzval_M_csr, rowptr_M_csr, colind_M_csr, perm, &num_rhs,
			iparmM, &msglvl, RHSTemp, a0, &error);
	//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	//Solve for each time step
	//	* Out put *//* Out put *//* Out put *//* Out put *//* Out put *//* Out put */
	plhs[0] = mxCreateDoubleMatrix(N_DoF, LengthTIMEPLOT, mxREAL);
	double *pr_out0 = mxGetPr(plhs[0]); // pointer pr_out will manage data in COLUMN Major.
	plhs[1] = mxCreateDoubleMatrix(N_DoF, LengthTIMEPLOT, mxREAL);
	double *pr_out1 = mxGetPr(plhs[1]); // pointer pr_out will manage data in COLUMN Major.
	plhs[2] = mxCreateDoubleMatrix(N_DoF, LengthTIMEPLOT, mxREAL);
	double *pr_out2 = mxGetPr(plhs[2]); // pointer pr_out will manage data in COLUMN Major.

	if (TIMEi == TIMEPLOT_pr[timenodeadd]-1) // first add to
	{
		cblas_dcopy(N_DoF, u0, 1, pr_out0, 1); // Cblas/Blas is COLUMN major
		cblas_dcopy(N_DoF, v0, 1, pr_out1, 1);
		cblas_dcopy(N_DoF, a0, 1, pr_out2, 1);
		timenodeadd++;
	}

	// at time =0, u_1 = u0 - v0*dt + a0*dt^2/2;
	double *u_1 = (double *) mxCalloc(N_DoF, sizeof(double));
	cblas_daxpy(N_DoF, 0.5 * pow(dt, 2), a0, 1, u_1, 1); // u_1 = a0*dt^2/2;
	cblas_daxpy(N_DoF, -1 * dt, v0, 1, u_1, 1); // u_1 = a0*dt^2/2 - v0*dt ;
	cblas_daxpy(N_DoF, 1, u0, 1, u_1, 1); // u_1 = a0*dt^2/2 - v0*dt + u0;

	// at time = dt (first step) // finding u_n1, v_n1, a_n1/ Known u_n=u0,v_n=v0, a_n=a0;
	TIMEi = 1;
	TIME = TIME_vec_pr[TIMEi];
	double *u_n_1 = (double *) mxCalloc(N_DoF, sizeof(double));
	cblas_dcopy(N_DoF, u_1, 1, u_n_1, 1); //u_n_1=u_1;
	double *u_n = (double *) mxCalloc(N_DoF, sizeof(double));
	cblas_dcopy(N_DoF, u0, 1, u_n, 1); // u_n =u0;
	double *v_n = (double *) mxCalloc(N_DoF, sizeof(double));
	cblas_dcopy(N_DoF, v0, 1, v_n, 1); // v_n=v0;

	//	r_eff= F(FreeIdcs) - K_Stiff*u_n + C_Damp*u_n_1/2/dt + M_Mass/dt^2*(2*u_n - u_n_1);
	memset(RHS, 0, N_DoF * sizeof(double)); // for automatically-allocated arrays
	cblas_daxpy(N_DoF, force(TIME), rhs, 1, RHS, 1);
	cblas_dcopy(N_DoF, RHS, 1, RHSTemp, 1); //	F(FreeIdcs)
	mkl_dcsrmv(&trans, &m_K, &n_K, &alpha1m, matdescra, nnzval_K_csr, colind_K_csr, rowptr_K_csr, rowptr_K_csr + 1, u_n,
			&beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n
	const double alpha1 = 1.0 / 2 / dt;
	mkl_dcsrmv(&trans, &m_C, &n_C, &alpha1, matdescra, nnzval_C_csr, colind_C_csr, rowptr_C_csr, rowptr_C_csr + 1,
			u_n_1, &beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n + C_Damp*u_n_1/2/dt
	const double alpha2 = 2.0 / pow(dt, 2);
	mkl_dcsrmv(&trans, &m_M, &n_M, &alpha2, matdescra, nnzval_M_csr, colind_M_csr, rowptr_M_csr, rowptr_M_csr + 1, u_n,
			&beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n + C_Damp*u_n_1/2/dt + M_Mass/dt^2*2*u_n
	const double alpha3 = -1.0 / pow(dt, 2);
	mkl_dcsrmv(&trans, &m_M, &n_M, &alpha3, matdescra, nnzval_M_csr, colind_M_csr, rowptr_M_csr, rowptr_M_csr + 1,
			u_n_1, &beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n + C_Damp*u_n_1/2/dt + M_Mass/dt^2*(2*u_n - u_n_1)

	//--configs for pardiso solver--
	_MKL_DSS_HANDLE_t ptLHS[64];
	MKL_INT mtypeLHS = 1; //real and structurally symmetric
	MKL_INT iparmLHS[64];
	PARDISOINIT(&ptLHS, &mtypeLHS, iparmLHS);
	iparmLHS[1] = 3; //parallel fill-in reducing ordering
	iparmLHS[4] = 0; //User permutation in the perm array is ignored.
	iparmLHS[5] = 0; //The array x contains the solution; right-hand side vector b is kept unchanged.

	iparmLHS[23] = 1; //use two-level scheduling factorization algorithm
	//iparm[24] = 1; //uses the sequential forward and backward solve.
	iparmLHS[26] = 1; //enable matrix checker
	iparmLHS[34] = 0; //use one-based indexing
	iparmLHS[36] = 0; //Use CSR format (see Three Array Variation of CSR Format) for matrix storage.
	//Analysis, Numerical factorization
	phase = 12;
	PARDISO(ptLHS, &maxfct, &mnum, &mtypeLHS, &phase, &m_LHS, nnzval_LHS_csr, rowptr_LHS_csr, colind_LHS_csr, perm,
			&num_rhs, iparmLHS, &msglvl, &x, &x, &error);
	if (error != 0)
	{
		switch (error)
		{
		case -1:
			mexErrMsgTxt("MKL Pardiso: analysis and numerical factorization error: input inconsistent");
			break;
		case -2:
			mexErrMsgTxt("MKL Pardiso: analysis and numerical factorization error: not enough memory");
			break;
		default:
			mexErrMsgTxt("MKL Pardiso: analysis and numerical factorization error");
			break;
		}
	}

	//Solve, iterative refinement
	double *u_n1 = (double *) mxCalloc(N_DoF, sizeof(double));
	phase = 33;
	PARDISO(ptLHS, &maxfct, &mnum, &mtypeLHS, &phase, &m_LHS, nnzval_LHS_csr, rowptr_LHS_csr, colind_LHS_csr, perm,
			&num_rhs, iparmLHS, &msglvl, RHSTemp, u_n1, &error);
	if (error != 0)
	{
		mexPrintf("Serious trouble happend. error = %d", error);
	}
	double *v_n1 = (double *) mxCalloc(N_DoF, sizeof(double));
	cblas_daxpy(N_DoF, 0.5 / dt, u_n1, 1, v_n1, 1); // v_n1=1/2/dt*(u_n1);
	cblas_daxpy(N_DoF, -0.5 / dt, u_n_1, 1, v_n1, 1); // v_n1=1/2/dt*(u_n1 - u_n_1);
	double *a_n1 = (double *) mxCalloc(N_DoF, sizeof(double));
	cblas_daxpy(N_DoF, 1.0 / pow(dt, 2), u_n1, 1, a_n1, 1); // a_n1=1/dt^2*(u_n1);
	cblas_daxpy(N_DoF, -2 / pow(dt, 2), u_n, 1, a_n1, 1); // a_n1=1/dt^2*(u_n1-2*u_n);
	cblas_daxpy(N_DoF, 1.0 / pow(dt, 2), u_n_1, 1, a_n1, 1); // a_n1=1/dt^2*(u_n1-2*u_n+u_n_1);

	//Update solution to Final matrix
	if (TIMEi == TIMEPLOT_pr[timenodeadd]-1) // next add to
	{
		cblas_dcopy(N_DoF, u_n1, 1, pr_out0 + (N_DoF * timenodeadd), 1); //
		cblas_dcopy(N_DoF, v_n1, 1, pr_out1 + (N_DoF * timenodeadd), 1); //
		cblas_dcopy(N_DoF, a_n1, 1, pr_out2 + (N_DoF * timenodeadd), 1); //
		timenodeadd++;
	}
	phase = 33;
	for (TIMEi = 2; TIMEi < NoTimeStep + 1; TIMEi++)
	{
		TIME = TIME_vec_pr[TIMEi];
		cblas_dcopy(N_DoF, u_n, 1, u_n_1, 1); //u_n_1=u_n (u0); u_n is keeping the value from u_n_1
		cblas_dcopy(N_DoF, u_n1, 1, u_n, 1); //u_n=u_n1;
		cblas_dcopy(N_DoF, v_n1, 1, v_n, 1); //v_n=v_n1;

		//	r_eff= F(FreeIdcs) - K_Stiff*u_n + C_Damp*u_n_1/2/dt + M_Mass/dt^2*(2*u_n - u_n_1);
		memset(RHS, 0, N_DoF * sizeof(double)); // for automatically-allocated arrays
		cblas_daxpy(N_DoF, force(TIME), rhs, 1, RHS, 1);
		cblas_dcopy(N_DoF, RHS, 1, RHSTemp, 1); //	F(FreeIdcs)
		mkl_dcsrmv(&trans, &m_K, &n_K, &alpha1m, matdescra, nnzval_K_csr, colind_K_csr, rowptr_K_csr, rowptr_K_csr + 1,
				u_n, &beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n
		mkl_dcsrmv(&trans, &m_C, &n_C, &alpha1, matdescra, nnzval_C_csr, colind_C_csr, rowptr_C_csr, rowptr_C_csr + 1,
				u_n_1, &beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n + C_Damp*u_n_1/2/dt
		mkl_dcsrmv(&trans, &m_M, &n_M, &alpha2, matdescra, nnzval_M_csr, colind_M_csr, rowptr_M_csr, rowptr_M_csr + 1,
				u_n, &beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n + C_Damp*u_n_1/2/dt + M_Mass/dt^2*2*u_n
		mkl_dcsrmv(&trans, &m_M, &n_M, &alpha3, matdescra, nnzval_M_csr, colind_M_csr, rowptr_M_csr, rowptr_M_csr + 1,
				u_n_1, &beta1, RHSTemp); //	F(FreeIdcs)- K_Stiff*u_n + C_Damp*u_n_1/2/dt + M_Mass/dt^2*(2*u_n - u_n_1)

		PARDISO(ptLHS, &maxfct, &mnum, &mtypeLHS, &phase, &m_LHS, nnzval_LHS_csr, rowptr_LHS_csr, colind_LHS_csr, perm,
				&num_rhs, iparmLHS, &msglvl, RHSTemp, u_n1, &error);
		if (error != 0)
		{
			mexPrintf("Serious trouble happend. error = %d", error);
		}
		// Update solution v_n1, a_n1 from known u_n1, u_n and u_n_1
		memset(v_n1, 0, N_DoF * sizeof(double)); // for automatically-allocated arrays
		memset(a_n1, 0, N_DoF * sizeof(double)); // for automatically-allocated arrays

		cblas_daxpy(N_DoF, 0.5 / dt, u_n1, 1, v_n1, 1); // v_n1=1/2/dt*(u_n1);
		cblas_daxpy(N_DoF, -0.5 / dt, u_n_1, 1, v_n1, 1); // v_n1=1/2/dt*(u_n1 - u_n_1);

		cblas_daxpy(N_DoF, 1.0 / pow(dt, 2), u_n1, 1, a_n1, 1); // a_n1=1/dt^2*(u_n1);
		cblas_daxpy(N_DoF, -2 / pow(dt, 2), u_n, 1, a_n1, 1); // a_n1=1/dt^2*(u_n1-2*u_n);
		cblas_daxpy(N_DoF, 1.0 / pow(dt, 2), u_n_1, 1, a_n1, 1); // a_n1=1/dt^2*(u_n1-2*u_n+u_n_1);

		//Update solution to Final matrix
		if (TIMEi == TIMEPLOT_pr[timenodeadd]-1) // next add to
		{
			cblas_dcopy(N_DoF, u_n1, 1, pr_out0 + (N_DoF * timenodeadd), 1); //
			cblas_dcopy(N_DoF, v_n1, 1, pr_out1 + (N_DoF * timenodeadd), 1); //
			cblas_dcopy(N_DoF, a_n1, 1, pr_out2 + (N_DoF * timenodeadd), 1); //
			timenodeadd++;
		}
	}
	// release memory
	phase = -1;
	MKL_INT error2 = 1;
	PARDISO(ptLHS, &maxfct, &mnum, &mtypeLHS, &phase, &m_LHS, nnzval_LHS_csr, rowptr_LHS_csr, colind_LHS_csr, perm,
			&num_rhs, iparmLHS, &msglvl, RHSTemp, u_n1, &error2);
	if (error2 != 0)
	{
		mexPrintf("MKL Pardiso: release memory error = %d", error);
	}
	PARDISO(ptM, &maxfct, &mnum, &mtypeM, &phase, &m_M, nnzval_M_csc, rowptr_M_csr, colind_M_csr, perm, &num_rhs,
			iparmM, &msglvl, RHSTemp, a0, &error);
	if (error2 != 0)
	{
		mexPrintf("MKL Pardiso: release memory error = %d", error);
	}

	mxFree(nnzval_K_csr);
	mxFree(colind_K_csr);
	mxFree(rowptr_K_csr);

	mxFree(nnzval_M_csr);
	mxFree(colind_M_csr);
	mxFree(rowptr_M_csr);

	mxFree(nnzval_C_csr);
	mxFree(colind_C_csr);
	mxFree(rowptr_C_csr);

	mxFree(nnzval_LHS_csr);
	mxFree(colind_LHS_csr);
	mxFree(rowptr_LHS_csr);

//	mxFree(u0);
	mxFree(v0);
	mxFree(a0);
	mxFree(RHS);
	mxFree(RHSTemp);

	mxFree(u_n_1);
	mxFree(u_1);
	mxFree(u_n);
	mxFree(v_n);

	mxFree(u_n1);
	mxFree(v_n1);
	mxFree(a_n1);

}
