clc;
clear all; 
close all;
% mex   -g -largeArrayDims '-IC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017\windows\mkl\include'...
%     '-LC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017\windows\mkl\lib\intel64_win'...
%     -lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core COMPFLAGS="/openmp $COMPFLAGS" CDM_Mex.cpp

% mex   -g -largeArrayDims '-IC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017\windows\mkl\include'...
%     '-LC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017\windows\mkl\lib\intel64_win'...
%     -lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core COMPFLAGS="/openmp $COMPFLAGS" ExRK_Mex.cpp

mex   -g -largeArrayDims '-IC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017\windows\mkl\include'...
    '-LC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017\windows\mkl\lib\intel64_win'...
    -lmkl_intel_lp64 -lmkl_intel_thread -lmkl_core COMPFLAGS="/openmp $COMPFLAGS" CDM_Mex.cpp
return
%%
% mex  -g -largeArrayDims '-IC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017.2.187\windows\mkl\include'...
%     '-LC:\Program Files (x86)\IntelSWTools\compilers_and_libraries_2017.2.187\windows\mkl\lib\intel64_win'...
%     -lmkl_intel_ilp64 -lmkl_intel_thread -lmkl_core COMPFLAGS="/openmp $COMPFLAGS" Solve_AXB_Mex.cpp
% 
% return

%%
% load KcMc
% Kcx=Kc(1:7,1:7);
% Kcx(4,1)=25;
Kcx=[1 -1 0 -3 0;
    -2 5 0 0 0;
    0 0 4 6 4;
    -4 0 2 7 0;
    0 8 0 0 -5];
 a=Solve_AXB_Mex(sparse(Kcx),Kcx);
%%
return
A= [6.80  -6.05  -0.45   8.32  -9.67;
 -2.11  -3.30   2.58   2.71  -5.14;
 5.66   5.36  -2.70   4.35  -7.26;
 5.97  -4.44   0.27  -7.17   6.08;
 8.23   1.08   9.04   2.14  -6.87];

B= [4.02  -1.56   9.81;
 6.19   4.00  -4.09;
 -8.22  -8.67  -4.57;
 -7.57   1.75  -8.61;
 -3.03   2.86   8.99];

X=A\B
x=matrixDivide(A,B(:,1))
[a,b]=Solve_AXB_Mex()


% A=[1.0  1.2  1.4  1.6  1.8  2.0  2.2  2.4  2.6;
%     1.2  1.0  1.2  1.4  1.6  1.8  2.0  2.2  2.4 ;
%     1.4  1.2  1.0  1.2  1.4  1.6  1.8  2.0  2.2 ;
%     1.6  1.4  1.2  1.0  1.2  1.4  1.6  1.8  2.0 ;
%     1.8  1.6  1.4  1.2  1.0  1.2  1.4  1.6  1.8 ;
%     2.0  1.8  1.6  1.4  1.2  1.0  1.2  1.4  1.6 ;
%     2.2  2.0  1.8  1.6  1.4  1.2  1.0  1.2  1.4 ;
%     2.4  2.2  2.0  1.8  1.6  1.4  1.2  1.0  1.2 ;
%     2.6  2.4  2.2  2.0  1.8  1.6  1.4  1.2  1.0 ];
% 
% 
% B =[ 93.0  ;
%     84.4  ;
%     76.6  ;
%     70.0 ;
%     65.0  ;
%     62.0  ;
%     61.4  ;
%     63.6  ;
%     69.0  ];
% % 
% % BXX   = [93.0  186.0  279.0  372.0  465.0;
% %     84.4  168.8  253.2  337.6  422.0;
% %     76.6  153.2  229.8  306.4  383.0 ;
% %     70.0  140.0  210.0  280.0  350.0;
% %     65.0  130.0  195.0  260.0  325.0;
% %     62.0  124.0  186.0  248.0  310.0 ;
% %     61.4  122.8  184.2  245.6  307.0 ;
% %     63.6  127.2  190.8  254.4  318.0 ;
% %     69.0  138.0  207.0  276.0  345.0];
% % X=A\BXX(:,5)
% 
% x=matrixDivide(A,B)
        